package test;

public class TestZXing {
    public static void main(String[] args) {
        System.out.println("ZXing imported successfully!");
    }
}