package util;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.common.BitMatrix;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

public class QRCodeGenerator {

    public static boolean generateQR(String data, String path) {

        try {

            // ✔ Create folder if not exist
            File file = new File(path);
            file.getParentFile().mkdirs();

            // ✔ Create QR writer
            QRCodeWriter writer = new QRCodeWriter();

            // ✔ Encode data into QR matrix
            BitMatrix matrix = writer.encode(
                    data,
                    BarcodeFormat.QR_CODE,
                    200,
                    200
            );

            // ✔ Create image
            BufferedImage image = new BufferedImage(
                    200,
                    200,
                    BufferedImage.TYPE_INT_RGB
            );

            // ✔ Fill image pixels
            for (int x = 0; x < 200; x++) {
                for (int y = 0; y < 200; y++) {

                    int color = matrix.get(x, y) ? 0x000000 : 0xFFFFFF;
                    image.setRGB(x, y, color);
                }
            }

            // ✔ Save QR image
            ImageIO.write(image, "png", file);

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}