package view;

import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import database.DBConnection;

public class SignUpForm extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;

    JTextField txtUsername;
    JPasswordField txtPassword;
    JComboBox<String> cmbRole;
    JButton btnSignUp, btnBack;
    
    public static void main(String[] args) {
        new SignUpForm();
    }
    public SignUpForm() {

        setTitle("Sign Up");
        setSize(350, 300);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel lblTitle = new JLabel("USER SIGN UP");
        lblTitle.setBounds(120, 20, 150, 25);
        add(lblTitle);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(30, 70, 100, 25);
        add(lblUsername);

        txtUsername = new JTextField();
        txtUsername.setBounds(120, 70, 150, 25);
        add(txtUsername);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(30, 110, 100, 25);
        add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(120, 110, 150, 25);
        add(txtPassword);

        JLabel lblRole = new JLabel("Role:");
        lblRole.setBounds(30, 150, 100, 25);
        add(lblRole);

        cmbRole = new JComboBox<>(new String[]{"Admin", "Staff"});
        cmbRole.setBounds(120, 150, 150, 25);
        add(cmbRole);

        btnSignUp = new JButton("Sign Up");
        btnSignUp.setBounds(50, 200, 100, 30);
        add(btnSignUp);

        btnBack = new JButton("Back");
        btnBack.setBounds(170, 200, 100, 30);
        add(btnBack);

        btnSignUp.addActionListener(this);
        btnBack.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btnSignUp) {
            registerUser();
        }

        if (e.getSource() == btnBack) {
            dispose();
            new LoginFrame();
        }
    }

    private void registerUser() {

        String username = txtUsername.getText();
        String password = String.valueOf(txtPassword.getPassword());
        String role = cmbRole.getSelectedItem().toString();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!");
            return;
        }

        try {
            Connection con = DBConnection.getConnection();

            // ✔ CHECK DUPLICATE USERNAME (FIXED)
            String checkSql = "SELECT * FROM users WHERE username=?";
            PreparedStatement checkPs = con.prepareStatement(checkSql);
            checkPs.setString(1, username);
            ResultSet rs = checkPs.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Username already exists!");
                return;
            }

            // ✔ INSERT USER (FIXED)
            String sql = "INSERT INTO users(username, password, role) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, role);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Sign up successful!");

            dispose();
            new LoginFrame();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
