package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import controller.StudentController;
import model.Student;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class StudentForm extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtCourse;
	private JTextField txtEmail;
	private JTextField txtPhone;
	private JTable tableStudent;
	private int selectedStudentId;

	private JButton btnAdd;
	private JButton btnSearch;
	private JButton btnUpdate;
	private JButton btnDelete;
	private JButton btnClear;
	private JButton btnBack;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentForm frame = new StudentForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public StudentForm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 501, 322);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(63, 14, 44, 12);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Course");
		lblNewLabel_2.setBounds(63, 44, 44, 12);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Email");
		lblNewLabel_3.setBounds(63, 74, 44, 12);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Phone");
		lblNewLabel_4.setBounds(63, 105, 44, 12);
		contentPane.add(lblNewLabel_4);
		
		txtName = new JTextField();
		txtName.setBounds(170, 11, 96, 18);
		contentPane.add(txtName);
		txtName.setColumns(10);
		
		txtCourse = new JTextField();
		txtCourse.setBounds(170, 41, 96, 18);
		contentPane.add(txtCourse);
		txtCourse.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setBounds(170, 74, 96, 18);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);
		
		txtPhone = new JTextField();
		txtPhone.setBounds(170, 102, 96, 18);
		contentPane.add(txtPhone);
		txtPhone.setColumns(10);
		
		btnAdd = new JButton("Add");

		btnAdd.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {

		        Student student = new Student();

		        student.setName(txtName.getText());
		        student.setCourse(txtCourse.getText());
		        student.setEmail(txtEmail.getText());
		        student.setPhone(txtPhone.getText());
		        student.setStatus("Active");

		        StudentController controller = new StudentController();

		        if(controller.addStudent(student)) {

		            JOptionPane.showMessageDialog(null,
		                    "Student Added Successfully!");

		            loadTable();

		            txtName.setText("");
		            txtCourse.setText("");
		            txtEmail.setText("");
		            txtPhone.setText("");

		        } else {

		            JOptionPane.showMessageDialog(null,
		                    "Failed to Add Student!");

		        }
		    }
		});

		btnAdd.setBounds(290, 9, 84, 22);
		contentPane.add(btnAdd);
		
		btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {

		    public void actionPerformed(ActionEvent e) {

		        String name = txtName.getText();

		        StudentController controller = new StudentController();

		        Student s = controller.searchStudent(name);

		        DefaultTableModel model = (DefaultTableModel) tableStudent.getModel();
		        model.setRowCount(0);

		        if (s != null) {

		            model.addRow(new Object[]{
		                s.getStudent_id(),
		                s.getName(),
		                s.getCourse(),
		                s.getEmail(),
		                s.getPhone()
		            });

		            // (optional) fill textfields
		            txtName.setText(s.getName());
		            txtCourse.setText(s.getCourse());
		            txtEmail.setText(s.getEmail());
		            txtPhone.setText(s.getPhone());

		        } else {
		            JOptionPane.showMessageDialog(null, "Student Not Found!");
		        }
		    }
		});
		btnSearch.setBounds(290, 44, 84, 22);
		contentPane.add(btnSearch);
		
		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {

		    public void actionPerformed(ActionEvent e) {

		        Student student = new Student();

		        student.setStudent_id(selectedStudentId);
		        student.setName(txtName.getText());
		        student.setCourse(txtCourse.getText());
		        student.setEmail(txtEmail.getText());
		        student.setPhone(txtPhone.getText());

		        StudentController controller = new StudentController();

		        if(controller.updateStudent(student)) {

		            JOptionPane.showMessageDialog(null,
		                    "Student Updated Successfully!");

		            loadTable();

		        } else {

		            JOptionPane.showMessageDialog(null,
		                    "Update Failed!");

		        }
		    }
		});

		btnUpdate.setBounds(290, 74, 84, 22);
		contentPane.add(btnUpdate);
		
		btnDelete = new JButton("Delete");

		btnDelete.addActionListener(new ActionListener() {

		    public void actionPerformed(ActionEvent e) {

		        StudentController controller =
		                new StudentController();

		        if(controller.softDeleteStudent(selectedStudentId)) {

		            JOptionPane.showMessageDialog(null,
		                    "Student Deleted Successfully!");

		            loadTable();

		            txtName.setText("");
		            txtCourse.setText("");
		            txtEmail.setText("");
		            txtPhone.setText("");

		        } else {

		            JOptionPane.showMessageDialog(null,
		                    "Delete Failed!");

		        }
		    }
		});

		btnDelete.setBounds(384, 9, 84, 22);
		contentPane.add(btnDelete);
		
		
		btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {

		        txtName.setText("");
		        txtCourse.setText("");
		        txtEmail.setText("");
		        txtPhone.setText("");

		        selectedStudentId = 0;

		    }
		});
		btnClear.setBounds(384, 44, 84, 22);
		contentPane.add(btnClear);
		
		btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {

		        dispose();

		        new Dashboard();

		    }
		});
		btnBack.setBounds(384, 74, 84, 22);
		contentPane.add(btnBack);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 145, 500, 180);
		contentPane.add(scrollPane);

		tableStudent = new JTable();
		scrollPane.setViewportView(tableStudent);
		

		tableStudent.addMouseListener(new java.awt.event.MouseAdapter() {

		    public void mouseClicked(java.awt.event.MouseEvent evt) {

		        int row = tableStudent.getSelectedRow();
		        selectedStudentId =
		        	    Integer.parseInt(tableStudent.getValueAt(row, 0).toString());

		        txtName.setText(tableStudent.getValueAt(row, 1).toString());
		        txtCourse.setText(tableStudent.getValueAt(row, 2).toString());
		        txtEmail.setText(tableStudent.getValueAt(row, 3).toString());
		        txtPhone.setText(tableStudent.getValueAt(row, 4).toString());

		    }

		});

		loadTable();

	}
	
	public void loadTable() {

	    StudentController controller = new StudentController();

	    ArrayList<Student> list = controller.getAllStudents();

	    DefaultTableModel model = new DefaultTableModel();

	    model.addColumn("ID");
	    model.addColumn("Name");
	    model.addColumn("Course");
	    model.addColumn("Email");
	    model.addColumn("Phone");

	    for(Student s : list){

	        model.addRow(new Object[]{
	            s.getStudent_id(),
	            s.getName(),
	            s.getCourse(),
	            s.getEmail(),
	            s.getPhone()
	        });

	    }

	    tableStudent.setModel(model);
	}
}
