package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.util.ArrayList;

import controller.CourseController;
import model.Course;
import javax.swing.JOptionPane;

public class CourseForm extends JFrame {
	private static final long serialVersionUID = 1L;
    private JTextField txtCourseName, txtLecturer;
    private JTable table;
    private int selectedCourseId = 0;

    private CourseController controller = new CourseController();

    public CourseForm() {

        setTitle("Course Management");
        setSize(600, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lbl1 = new JLabel("Course Name");
        lbl1.setBounds(30, 30, 100, 25);
        add(lbl1);

        txtCourseName = new JTextField();
        txtCourseName.setBounds(140, 30, 150, 25);
        add(txtCourseName);

        JLabel lbl2 = new JLabel("Lecturer");
        lbl2.setBounds(30, 70, 100, 25);
        add(lbl2);

        txtLecturer = new JTextField();
        txtLecturer.setBounds(140, 70, 150, 25);
        add(txtLecturer);

        JButton btnAdd = new JButton("Add");
        btnAdd.setBounds(320, 30, 100, 25);
        add(btnAdd);

        JButton btnUpdate = new JButton("Update");
        btnUpdate.setBounds(320, 70, 100, 25);
        add(btnUpdate);

        JButton btnDelete = new JButton("Delete");
        btnDelete.setBounds(430, 30, 100, 25);
        add(btnDelete);

        JButton btnClear = new JButton("Clear");
        btnClear.setBounds(430, 70, 100, 25);
        add(btnClear);

        // ⭐ BACK BUTTON ADDED
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(320, 110, 210, 25);
        add(btnBack);

        JScrollPane sp = new JScrollPane();
        sp.setBounds(30, 150, 500, 250);
        add(sp);

        table = new JTable();
        sp.setViewportView(table);

        // ================= LOAD TABLE =================
        loadTable();

        // ================= TABLE CLICK =================
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {

                int row = table.getSelectedRow();

                selectedCourseId = Integer.parseInt(
                        table.getValueAt(row, 0).toString()
                );

                txtCourseName.setText(table.getValueAt(row, 1).toString());
                txtLecturer.setText(table.getValueAt(row, 2).toString());
            }
        });

        // ================= ADD =================
        btnAdd.addActionListener(e -> {

            Course c = new Course();
            c.setCourseName(txtCourseName.getText());
            c.setLecturer(txtLecturer.getText());

            if (controller.addCourse(c)) {
                JOptionPane.showMessageDialog(null, "Course Added!");
                loadTable();
                clear();
            } else {
                JOptionPane.showMessageDialog(null, "Failed to Add!");
            }
        });

        // ================= UPDATE =================
        btnUpdate.addActionListener(e -> {

            Course c = new Course();
            c.setCourseId(selectedCourseId);
            c.setCourseName(txtCourseName.getText());
            c.setLecturer(txtLecturer.getText());

            if (controller.updateCourse(c)) {
                JOptionPane.showMessageDialog(null, "Updated!");
                loadTable();
                clear();
            } else {
                JOptionPane.showMessageDialog(null, "Update Failed!");
            }
        });

        // ================= DELETE =================
        btnDelete.addActionListener(e -> {

            if (controller.deleteCourse(selectedCourseId)) {
                JOptionPane.showMessageDialog(null, "Deleted!");
                loadTable();
                clear();
            } else {
                JOptionPane.showMessageDialog(null, "Delete Failed!");
            }
        });

        // ================= CLEAR =================
        btnClear.addActionListener(e -> clear());

        // ================= BACK =================
        btnBack.addActionListener(e -> {
            dispose();
            new Dashboard().setVisible(true);
        });

        setVisible(true);
    }

    // ================= LOAD TABLE =================
    private void loadTable() {

        ArrayList<Course> list = controller.getAllCourses();

        DefaultTableModel model = new DefaultTableModel();

        model.addColumn("ID");
        model.addColumn("Course Name");
        model.addColumn("Lecturer");

        for (Course c : list) {
            model.addRow(new Object[]{
                    c.getCourseId(),
                    c.getCourseName(),
                    c.getLecturer()
            });
        }

        table.setModel(model);
    }

    // ================= CLEAR =================
    private void clear() {
        txtCourseName.setText("");
        txtLecturer.setText("");
        selectedCourseId = 0;
    }

    // ================= MAIN =================
    public static void main(String[] args) {
        new CourseForm();
    }
}