package view;

import javax.swing.*;
import java.awt.event.*;

public class Dashboard extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
    JButton btnStudent;
    JButton btnAttendance;
    JButton btnCourse;
    JButton btnLogout;
    public static void main(String[] args) {
        new Dashboard();
    }
    public Dashboard() {

        setTitle("Smart Attendance Management System");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        // ===== TITLE =====
        JLabel title = new JLabel("SMART ATTENDANCE MANAGEMENT SYSTEM");
        title.setBounds(70, 30, 400, 30);
        getContentPane().add(title);

        // ===== STUDENT BUTTON =====
        btnStudent = new JButton("Student Management");
        btnStudent.setBounds(140, 90, 200, 40);
        getContentPane().add(btnStudent);
        
        btnCourse = new JButton("Course Management");
        btnCourse.setBounds(140, 140, 200, 40);
        getContentPane().add(btnCourse);

        // ===== ATTENDANCE BUTTON =====
        btnAttendance = new JButton("Attendance Management");
        btnAttendance.setBounds(140, 190, 200, 40);
        getContentPane().add(btnAttendance);

        // ===== LOGOUT BUTTON =====
        btnLogout = new JButton("Logout");
        btnLogout.setBounds(180, 247, 120, 35);
        getContentPane().add(btnLogout);

        // ===== ACTION LISTENERS =====
        btnStudent.addActionListener(this);
        btnCourse.addActionListener(this);
        btnAttendance.addActionListener(this);
        btnLogout.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btnLogout) {
            dispose();
            new LoginFrame();
        }

        if (e.getSource() == btnStudent) {
            System.out.println("Opening StudentForm");
            new StudentForm().setVisible(true);
            dispose();
        }
        
        if (e.getSource() == btnCourse) {
            new CourseForm().setVisible(true);
            dispose();
        }

        if (e.getSource() == btnAttendance) {
            new AttendanceForm();
            this.dispose();
        }
    }
}