package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import controller.LoginController;

public class LoginFrame extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    JLabel lblTitle, lblUsername, lblPassword;
    JTextField txtUsername;
    JPasswordField txtPassword;

    JButton btnLogin, btnExit, btnSignUp;

    public LoginFrame() {

        setTitle("Smart Attendance Management System");
        setSize(450, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // ===== TITLE =====
        lblTitle = new JLabel("SMART ATTENDANCE MANAGEMENT SYSTEM");
        lblTitle.setBounds(40, 20, 360, 30);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 12));
        add(lblTitle);

        // ===== USERNAME =====
        lblUsername = new JLabel("Username");
        lblUsername.setBounds(50, 80, 100, 25);
        add(lblUsername);

        txtUsername = new JTextField();
        txtUsername.setBounds(150, 80, 180, 25);
        add(txtUsername);

        // ===== PASSWORD =====
        lblPassword = new JLabel("Password");
        lblPassword.setBounds(50, 120, 100, 25);
        add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(150, 120, 180, 25);
        add(txtPassword);

        // ===== LOGIN BUTTON =====
        btnLogin = new JButton("Login");
        btnLogin.setBounds(50, 180, 100, 30);
        add(btnLogin);

        // ===== SIGN UP BUTTON =====
        btnSignUp = new JButton("Sign Up");
        btnSignUp.setBounds(160, 180, 100, 30);
        add(btnSignUp);

        // ===== EXIT BUTTON =====
        btnExit = new JButton("Exit");
        btnExit.setBounds(270, 180, 100, 30);
        add(btnExit);

        // ===== ACTION LISTENERS =====
        btnLogin.addActionListener(this);
        btnExit.addActionListener(this);
        btnSignUp.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // ===== EXIT =====
        if (e.getSource() == btnExit) {
            System.exit(0);
        }

        // ===== LOGIN =====
        if (e.getSource() == btnLogin) {

            String username = txtUsername.getText();
            String password = String.valueOf(txtPassword.getPassword());

            LoginController controller = new LoginController();

            if (controller.login(username, password)) {

                JOptionPane.showMessageDialog(this, "Login Successful!");

                dispose();
                Dashboard dashboard = new Dashboard();
                dashboard.setVisible(true);

            } else {

                JOptionPane.showMessageDialog(this,
                        "Invalid Username or Password!");
            }
        }

        // ===== SIGN UP =====
        if (e.getSource() == btnSignUp) {

            SignUpForm signUp = new SignUpForm();
            signUp.setVisible(true);

            dispose(); // remove this line if you want both windows open
        }
    }

    public static void main(String[] args) {
        new LoginFrame();
    }
}