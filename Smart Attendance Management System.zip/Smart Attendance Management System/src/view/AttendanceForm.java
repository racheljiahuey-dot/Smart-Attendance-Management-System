package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import javax.swing.ButtonGroup;

import controller.StudentController;
import controller.AttendanceController;

import model.Student;
import model.Attendance;

import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import org.jfree.chart.plot.PlotOrientation;
import util.QRScanner;

// ⭐ ADDED IMPORTS (PIE CHART)
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;

import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;

//⭐ iTextPDF IMPORTS
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;


public class AttendanceForm extends JFrame {    
private JPanel contentPane;

    private JComboBox<String> cmbStudent;
    private StudentController studentController = new StudentController();
    private AttendanceController attendanceController = new AttendanceController();

    private JRadioButton rbPresent;
    private JRadioButton rbAbsent;
    private ButtonGroup group;

    private JButton btnSave;
    private JButton btnClear;
    private JButton btnBack;
    private JButton btnScan;

    private JTable table;

    private JLabel qrLabel;

    private ChartPanel chartPanel;
    private ChartPanel barChartPanel;
    private JButton btnPdfReport;
    private JLabel lblPdfTitle;
    
    public AttendanceForm() {

        setTitle("Attendance Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(50, 30, 1400, 850);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5,5,5,5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblStudent = new JLabel("Student");
        lblStudent.setBounds(50,30,80,25);
        contentPane.add(lblStudent);

        cmbStudent = new JComboBox<>();
        cmbStudent.setBounds(150,30,180,25);
        contentPane.add(cmbStudent);

        JLabel lblStatus = new JLabel("Status");
        lblStatus.setBounds(50,70,80,25);
        contentPane.add(lblStatus);

        rbPresent = new JRadioButton("Present");
        rbPresent.setBounds(150,70,90,25);
        contentPane.add(rbPresent);

        rbAbsent = new JRadioButton("Absent");
        rbAbsent.setBounds(250,70,90,25);
        contentPane.add(rbAbsent);

        group = new ButtonGroup();
        group.add(rbPresent);
        group.add(rbAbsent);

        btnSave = new JButton("Save");
        btnSave.setBounds(380,30,100,30);
        contentPane.add(btnSave);

        btnClear = new JButton("Clear");
        btnClear.setBounds(380,70,100,30);
        contentPane.add(btnClear);

        btnBack = new JButton("Back");
        btnBack.setBounds(500,30,100,30);
        contentPane.add(btnBack);

        btnScan = new JButton("Scan QR");
        btnScan.setBounds(500, 70, 120, 30);
        contentPane.add(btnScan);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(30,130,900,300);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

        loadStudents();
        loadAttendanceTable();

        // ⭐ ADDED CHART CALL
        loadAttendanceChart();
        loadCourseBarChart();
        
     // ⭐ PDF REPORT TITLE (UNDER PIE CHART)
        lblPdfTitle = new JLabel("Attendance Full Report");
        lblPdfTitle.setFont(new Font("Arial", Font.BOLD, 18));
        lblPdfTitle.setBounds(950, 580, 300, 30);
        contentPane.add(lblPdfTitle);

        // ⭐ VIEW PDF BUTTON
        btnPdfReport = new JButton("View Report");
        btnPdfReport.setBounds(950, 620, 150, 30);
        contentPane.add(btnPdfReport);
        btnPdfReport.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {

                    ArrayList<Attendance> list = attendanceController.getAllAttendance();

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();

                    Document document = new Document();
                    PdfWriter.getInstance(document, baos);

                    document.open();

                    // ================= HEADER =================
                    Paragraph header = new Paragraph("SMART ATTENDANCE SYSTEM");
                    header.setAlignment(Paragraph.ALIGN_CENTER);
                    header.setFont(new com.itextpdf.text.Font(
                            com.itextpdf.text.Font.FontFamily.HELVETICA,
                            18,
                            com.itextpdf.text.Font.BOLD
                    ));
                    document.add(header);

                    Paragraph subHeader = new Paragraph("ATTENDANCE REPORT");
                    subHeader.setAlignment(Paragraph.ALIGN_CENTER);
                    subHeader.setFont(new com.itextpdf.text.Font(
                            com.itextpdf.text.Font.FontFamily.HELVETICA,
                            14,
                            com.itextpdf.text.Font.NORMAL
                    ));
                    document.add(subHeader);

                    document.add(new Paragraph(" "));
                    document.add(new Paragraph("Generated Date: " + java.time.LocalDate.now()));
                    document.add(new Paragraph(" "));

                    // ================= TABLE =================
                    PdfPTable table = new PdfPTable(7);
                    table.setWidthPercentage(100);

                    float[] columnWidths = {2f, 2f, 3f, 3f, 2f, 2f, 2f};
                    table.setWidths(columnWidths);

                    // ===== HEADER STYLE =====
                    com.itextpdf.text.Font headFont = new com.itextpdf.text.Font(
                            com.itextpdf.text.Font.FontFamily.HELVETICA,
                            12,
                            com.itextpdf.text.Font.BOLD,
                            com.itextpdf.text.BaseColor.WHITE
                    );

                    com.itextpdf.text.pdf.PdfPCell cell;

                    String[] headers = {
                    	    "ID",
                    	    "Student ID",
                    	    "Course Name",
                    	    "Lecturer",
                    	    "Date",
                    	    "Time",
                    	    "Status"
                    	};

                    for (String h : headers) {
                        cell = new com.itextpdf.text.pdf.PdfPCell(new Paragraph(h, headFont));
                        cell.setBackgroundColor(new com.itextpdf.text.BaseColor(41, 128, 185)); // BLUE
                        cell.setHorizontalAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
                        cell.setPadding(5);
                        table.addCell(cell);
                    }

                    // ================= DATA ROWS =================
                    for (Attendance a : list) {

                        table.addCell(String.valueOf(a.getAttendanceId()));
                        table.addCell(String.valueOf(a.getStudentId()));
                        table.addCell(a.getCourseName());   //  NEW
                        table.addCell(a.getLecturer());     //  NEW
                        table.addCell(a.getDate());
                        table.addCell(a.getTime());

                        String status = a.getStatus();

                        com.itextpdf.text.BaseColor color;

                        if (status.equalsIgnoreCase("Present")) {
                            status = "PRESENT";
                            color = new com.itextpdf.text.BaseColor(46, 204, 113); // GREEN
                        } else {
                            status = "ABSENT";
                            color = new com.itextpdf.text.BaseColor(231, 76, 60); // RED
                        }

                        com.itextpdf.text.pdf.PdfPCell statusCell =
                                new com.itextpdf.text.pdf.PdfPCell(new Paragraph(status));

                        statusCell.setBackgroundColor(color);
                        statusCell.setHorizontalAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
                        statusCell.setPadding(5);

                        table.addCell(statusCell);
                    }

                    document.add(table);

                    // ================= SUMMARY ================
                    long present = list.stream()
                            .filter(a -> a.getStatus().equalsIgnoreCase("Present"))
                            .count();

                    long absent = list.stream()
                            .filter(a -> a.getStatus().equalsIgnoreCase("Absent"))
                            .count();

                    document.add(new Paragraph(" "));

                    Paragraph summaryTitle = new Paragraph("SUMMARY");
                    summaryTitle.setFont(new com.itextpdf.text.Font(
                            com.itextpdf.text.Font.FontFamily.HELVETICA,
                            14,
                            com.itextpdf.text.Font.BOLD
                    ));

                    document.add(summaryTitle);

                    document.add(new Paragraph("Total Present: " + present));
                    document.add(new Paragraph("Total Absent: " + absent));

                    double percent = (list.size() == 0)
                            ? 0
                            : (present * 100.0 / list.size());

                    document.add(new Paragraph(
                            "Attendance Rate: " + String.format("%.2f", percent) + "%"
                    ));

                    document.close();
                    
                    // ================= SAVE FILE =================
                    String filePath = "D:\\Downloads\\Attendance_Report.pdf";
                    FileOutputStream fos = new FileOutputStream(filePath);
                    fos.write(baos.toByteArray());
                    fos.close();

                    JOptionPane.showMessageDialog(null,
                            "Professional PDF Generated Successfully!\nSaved at:\n" + filePath);

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "PDF Error: " + ex.getMessage());
                }
            }
        });

        // ================= SAVE =================
        btnSave.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                if (cmbStudent.getSelectedItem() == null) {
                    JOptionPane.showMessageDialog(null, "No student selected!");
                    return;
                }

                String selected = cmbStudent.getSelectedItem().toString();
                int studentId = Integer.parseInt(selected.split(" - ")[0]);
                String studentName = selected.split(" - ")[1];

                String status = "";

                if (rbPresent.isSelected()) {
                    status = "Present";
                } else if (rbAbsent.isSelected()) {
                    status = "Absent";
                } else {
                    JOptionPane.showMessageDialog(null, "Please select attendance status!");
                    return;
                }

                String date = java.time.LocalDate.now().toString();
                String time = java.time.LocalTime.now().toString();

                Attendance attendance = new Attendance();
                attendance.setStudentId(studentId);
                attendance.setDate(date);
                attendance.setTime(time);
                attendance.setStatus(status);

                if (attendanceController.addAttendance(attendance)) {

                    loadAttendanceTable();
                    loadAttendanceChart(); // ⭐ ADDED ONLY
                    loadStudentBarChart();

                    group.clearSelection();

                    String data = studentId + "," + studentName;
                    String path = "D:\\Eclipse Java\\Workspace\\Smart Attendance Management System\\QR student\\student_" + studentId + ".png";

                    boolean qrSuccess = util.QRCodeGenerator.generateQR(data, path);

                    if (qrLabel != null) {
                        contentPane.remove(qrLabel);
                        qrLabel = null;
                    }

                    if (qrSuccess) {
                        ImageIcon icon = new ImageIcon(path);
                        qrLabel = new JLabel(icon);
                        qrLabel.setBounds(1120, 30, 220, 220);
                        contentPane.add(qrLabel);
                        contentPane.revalidate();
                        contentPane.repaint();
                    }

                    double percent = attendanceController.getAttendancePercentage(studentId);

                    String message = "Attendance Saved Successfully!\n"
                            + "Attendance: " + String.format("%.2f", percent) + "%";

                    if (percent < 75) {
                        message += "\n⚠ WARNING: Low Attendance!";
                    } else {
                        message += "\n✔ Good Attendance";
                    }

                    if (qrSuccess) {
                        message += "\n✔ QR Generated Successfully!";
                    } else {
                        message += "\n❌ QR Generation Failed!";
                    }

                    JOptionPane.showMessageDialog(null, message);

                } else {
                    JOptionPane.showMessageDialog(null, "Failed to Save Attendance!");
                }
            }
        });

        // ================= CLEAR =================
        btnClear.addActionListener(e -> {
            group.clearSelection();
            if (cmbStudent.getItemCount() > 0) {
                cmbStudent.setSelectedIndex(0);
            }
        });

        // ================= BACK =================
        btnBack.addActionListener(e -> {
            new Dashboard();
            dispose();
        });

        // ================= SCAN =================
        btnScan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                JFileChooser chooser = new JFileChooser();
                int result = chooser.showOpenDialog(null);

                if (result != JFileChooser.APPROVE_OPTION) return;

                String path = chooser.getSelectedFile().getAbsolutePath();
                String qrData = QRScanner.readQR(path);

                if (qrData == null) {
                    JOptionPane.showMessageDialog(null, "Invalid QR Code!");
                    return;
                }

                String[] data = qrData.split(",");

                if (data.length < 2) {
                    JOptionPane.showMessageDialog(null, "Invalid QR Format!");
                    return;
                }

                int studentId = Integer.parseInt(data[0].trim());
                String studentName = data[1].trim();

                String date = java.time.LocalDate.now().toString();

                Attendance attendance = new Attendance();
                attendance.setStudentId(studentId);
                attendance.setDate(date);
                attendance.setTime(java.time.LocalTime.now().toString());
                attendance.setStatus("Present");

                if (attendanceController.addAttendance(attendance)) {

                    loadAttendanceTable();
                    loadAttendanceChart();
                    loadStudentBarChart();

                    JOptionPane.showMessageDialog(null,
                            "Attendance Marked!\nStudent: " + studentName);

                } else {
                    JOptionPane.showMessageDialog(null,
                            "Failed to mark attendance!");
                }
            }
        });

        setVisible(true);
    }    
public static void main(String[] args) {
        new AttendanceForm();
    }

    // ================= LOAD STUDENTS =================
    public void loadStudents() {

        ArrayList<Student> list = studentController.getAllStudents();
        cmbStudent.removeAllItems();

        for (Student s : list) {
            cmbStudent.addItem(s.getStudent_id() + " - " + s.getName());
        }
    }

    // ================= LOAD ATTENDANCE TABLE =================
    public void loadAttendanceTable() {

        ArrayList<Attendance> list = attendanceController.getAllAttendance();

        DefaultTableModel model = new DefaultTableModel();

        model.addColumn("ID");
        model.addColumn("Student ID");
        model.addColumn("Student Name");
        model.addColumn("Course");
        model.addColumn("Lecturer");
        model.addColumn("Date");
        model.addColumn("Time");
        model.addColumn("Status");

        for (Attendance a : list) {
            model.addRow(new Object[]{
                    a.getAttendanceId(),
                    a.getStudentId(),
                    a.getStudentName(),   // NEW
                    a.getCourseName(),    // NEW
                    a.getLecturer(),      // NEW
                    a.getDate(),
                    a.getTime(),
                    a.getStatus()
            });
        }

        table.setModel(model);
    }

 // ================= PIE CHART =================
    public void loadAttendanceChart() {

        int present = attendanceController.countPresent();
        int absent = attendanceController.countAbsent();

        DefaultPieDataset dataset = new DefaultPieDataset();

        dataset.setValue("Present", present);
        dataset.setValue("Absent", absent);

        JFreeChart chart = ChartFactory.createPieChart(
                "Attendance Overview",
                dataset,
                true,
                true,
                false
        );

        chart.setBackgroundPaint(Color.WHITE);
        chart.getTitle().setFont(new Font("Arial", Font.BOLD, 24));

        org.jfree.chart.plot.PiePlot plot =
                (org.jfree.chart.plot.PiePlot) chart.getPlot();

        plot.setSectionPaint("Present", new Color(46,204,113));
        plot.setSectionPaint("Absent", new Color(231,76,60));

        plot.setLabelFont(new Font("Arial", Font.BOLD, 12));

        plot.setLabelGenerator(
                new org.jfree.chart.labels.StandardPieSectionLabelGenerator(
                        "{0}: {1} ({2})",
                        new java.text.DecimalFormat("0"),
                        new java.text.DecimalFormat("0%")
                )
        );

        if (chartPanel != null) {
            contentPane.remove(chartPanel);
        }

        chartPanel = new ChartPanel(chart);
        chartPanel.setBounds(950,250,420,320);
        contentPane.add(chartPanel);

        contentPane.revalidate();
        contentPane.repaint();
    }
    
 // ================= STUDENT BAR CHART =================
    public void loadStudentBarChart() {

        DefaultCategoryDataset dataset =
                new DefaultCategoryDataset();

        ArrayList<Student> students =
                studentController.getAllStudents();

        for(Student s : students) {

            double percent =
                    attendanceController.getAttendancePercentage(
                            s.getStudent_id());

            dataset.addValue(
                    percent,
                    "Attendance %",
                    s.getName()
            );
        }

        JFreeChart chart =
                ChartFactory.createBarChart(
                        "Student Attendance Performance",
                        "Student",
                        "Attendance %",
                        dataset,
                        PlotOrientation.VERTICAL,
                        false,
                        true,
                        false
                );

        chart.setBackgroundPaint(Color.WHITE);

        chart.getTitle().setFont(
                new Font("Arial", Font.BOLD, 26));

        CategoryPlot plot =
                chart.getCategoryPlot();

        plot.setBackgroundPaint(
                new Color(245,248,255));

        plot.setRangeGridlinePaint(
                Color.GRAY);

        GradientPaint gradient =
                new GradientPaint(
                        0,0,
                        new Color(52,152,219),
                        0,300,
                        new Color(41,128,185)
                );

        BarRenderer renderer =
                (BarRenderer) plot.getRenderer();

        renderer.setSeriesPaint(
                0,
                gradient);

        renderer.setMaximumBarWidth(0.10);

        renderer.setBaseItemLabelGenerator(
                new StandardCategoryItemLabelGenerator()
        );

        renderer.setBaseItemLabelsVisible(true);
        renderer.setItemMargin(0.15);

        NumberAxis rangeAxis =
                (NumberAxis) plot.getRangeAxis();

        rangeAxis.setRange(0,100);

        plot.getDomainAxis().setLabelFont(
                new Font("Arial", Font.BOLD, 16));

        plot.getRangeAxis().setLabelFont(
                new Font("Arial", Font.BOLD, 16));

        plot.getDomainAxis().setTickLabelFont(
                new Font("Arial", Font.PLAIN, 14));

        plot.getRangeAxis().setTickLabelFont(
                new Font("Arial", Font.PLAIN, 14));

        if(barChartPanel != null) {
            contentPane.remove(barChartPanel);
        }

        barChartPanel = new ChartPanel(chart);

        barChartPanel.setBounds(
                30,
                460,
                900,
                300
        );

        contentPane.add(barChartPanel);

        contentPane.revalidate();
        contentPane.repaint();
    }
 // ================= COURSE BAR CHART (NEW) =================
    public void loadCourseBarChart() {

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        ArrayList<Object[]> list = attendanceController.getAttendanceByCourse();

        for (Object[] row : list) {

            String courseName = row[0].toString();
            int present = Integer.parseInt(row[1].toString());
            int total = Integer.parseInt(row[2].toString());

            double percent = (total == 0) ? 0 : (present * 100.0 / total);

            dataset.addValue(percent, "Attendance %", courseName);
        }

        JFreeChart chart = ChartFactory.createBarChart(
                "Attendance by Course",
                "Course",
                "Percentage (%)",
                dataset,
                PlotOrientation.VERTICAL,
                false,
                true,
                false
        );

        CategoryPlot plot = chart.getCategoryPlot();
        plot.getRangeAxis().setRange(0, 100);
        BarRenderer renderer = (BarRenderer) plot.getRenderer();

        Color[] colors = {
            new Color(52, 152, 219),
            new Color(46, 204, 113),
            new Color(155, 89, 182),
            new Color(241, 196, 15),
            new Color(231, 76, 60),
            new Color(52, 73, 94)
        };

        for (int i = 0; i < dataset.getColumnCount(); i++) {
            renderer.setSeriesPaint(i, colors[i % colors.length]);
        }
        if (barChartPanel != null) {
            contentPane.remove(barChartPanel);
        }

        barChartPanel = new ChartPanel(chart);
        barChartPanel.setBounds(30, 460, 900, 300);

        contentPane.add(barChartPanel);
        contentPane.revalidate();
        contentPane.repaint();
    }
}