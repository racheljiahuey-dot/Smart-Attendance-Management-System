package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcExample {

    public static void main(String[] args) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/smartattendancesystem",
                    "root",
                    ""
            );

            System.out.println("Connection created successfully!");

            // ✔ use connection (important to remove warning)
            if (con != null) {
                System.out.println("Database connected: " + con.getCatalog());
            }

            con.close();

        } catch (ClassNotFoundException e) {
            System.out.println("MySQL Driver not found!");
            e.printStackTrace();

        } catch (SQLException e) {
            System.out.println("Database connection failed!");
            e.printStackTrace();
        }
    }
}