package jdbc;

import controller.StudentController;
import model.Student;
import java.util.ArrayList;

public class ViewStudent {

    public static void main(String[] args) {

        StudentController controller = new StudentController();

        ArrayList<Student> students = controller.getAllStudents();

        for (Student s : students) {

            System.out.println("Student ID : " + s.getStudent_id());
            System.out.println("Name       : " + s.getName());
            System.out.println("Course     : " + s.getCourse());
            System.out.println("Email      : " + s.getEmail());
            System.out.println("Phone      : " + s.getPhone());
            System.out.println("Status     : " + s.getStatus());
            System.out.println("------------------------------");
        }
    }
}
