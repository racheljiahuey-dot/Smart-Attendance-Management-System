package jdbc;

import controller.StudentController;
import model.Student;

public class UpdateStudent {

    public static void main(String[] args) {

        Student student = new Student();

        // Update student with ID 1
        student.setStudent_id(1);
        student.setName("Rachel Tan");
        student.setCourse("BITP");
        student.setEmail("rachel_tan@gmail.com");
        student.setPhone("01122334455");

        StudentController controller = new StudentController();

        if (controller.updateStudent(student)) {
            System.out.println("Student updated successfully!");
        } else {
            System.out.println("Update failed!");
        }
    }
}