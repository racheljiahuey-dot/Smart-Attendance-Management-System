package jdbc;

import controller.StudentController;
import model.Student;

public class TestStudent {

    public static void main(String[] args) {

        Student student = new Student();

        student.setName("Rachel");
        student.setCourse("BITP");
        student.setEmail("rachel@gmail.com");
        student.setPhone("0123456789");
        student.setStatus("Active");

        StudentController controller = new StudentController();

        if (controller.addStudent(student)) {
            System.out.println("Student added successfully!");
        } else {
            System.out.println("Failed to add student.");
        }
    }
}