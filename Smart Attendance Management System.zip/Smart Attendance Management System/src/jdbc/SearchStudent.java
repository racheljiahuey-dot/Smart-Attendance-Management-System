package jdbc;

import controller.StudentController;
import model.Student;

public class SearchStudent {

    public static void main(String[] args) {

        StudentController controller = new StudentController();

        Student student = controller.searchStudent("Siti");

        if (student != null) {

            System.out.println("Student Found");
            System.out.println("ID      : " + student.getStudent_id());
            System.out.println("Name    : " + student.getName());
            System.out.println("Course  : " + student.getCourse());
            System.out.println("Email   : " + student.getEmail());
            System.out.println("Phone   : " + student.getPhone());

        } else {

            System.out.println("Student not found");
        }
    }
}