package jdbc;

import controller.StudentController;

public class DeleteStudent {

    public static void main(String[] args) {

        StudentController controller = new StudentController();

        if (controller.softDeleteStudent(1)) {
            System.out.println("Student soft deleted successfully!");
        } else {
            System.out.println("Soft delete failed!");
        }

    }
}