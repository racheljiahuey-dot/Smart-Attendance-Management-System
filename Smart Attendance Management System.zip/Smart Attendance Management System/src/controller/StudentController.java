package controller;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Student;
import java.sql.ResultSet;
import java.util.ArrayList;
public class StudentController {

    public boolean addStudent(Student student) {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO student(name, course, email, phone, status) VALUES(?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, student.getName());
            ps.setString(2, student.getCourse());
            ps.setString(3, student.getEmail());
            ps.setString(4, student.getPhone());
            ps.setString(5, student.getStatus());

            ps.executeUpdate();

            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public ArrayList<Student> getAllStudents() {

        ArrayList<Student> list = new ArrayList<>();

        try {

            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM student WHERE status='Active'";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Student s = new Student();

                s.setStudent_id(rs.getInt("student_id"));
                s.setName(rs.getString("name"));
                s.setCourse(rs.getString("course"));
                s.setEmail(rs.getString("email"));
                s.setPhone(rs.getString("phone"));
                s.setStatus(rs.getString("status"));

                list.add(s);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    
    public Student searchStudent(String name) {

        Student student = null;

        try {

            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM student WHERE name=? AND status='Active'";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, name);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                student = new Student();

                student.setStudent_id(rs.getInt("student_id"));
                student.setName(rs.getString("name"));
                student.setCourse(rs.getString("course"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getString("phone"));
                student.setStatus(rs.getString("status"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return student;
    }
    
    public boolean updateStudent(Student student) {

        try {

            Connection con = DBConnection.getConnection();

            String sql = "UPDATE student SET name=?, course=?, email=?, phone=? WHERE student_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, student.getName());
            ps.setString(2, student.getCourse());
            ps.setString(3, student.getEmail());
            ps.setString(4, student.getPhone());
            ps.setInt(5, student.getStudent_id());

            ps.executeUpdate();

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean softDeleteStudent(int id) {

        try {

            Connection con = DBConnection.getConnection();

            String sql = "UPDATE student SET status='Inactive' WHERE student_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}