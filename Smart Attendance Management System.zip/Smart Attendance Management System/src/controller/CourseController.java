package controller;

import database.DBConnection;
import model.Course;

import java.sql.*;
import java.util.ArrayList;

public class CourseController {

    public boolean addCourse(Course c) {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO course(course_name, lecturer) VALUES(?,?)";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, c.getCourseName());
            ps.setString(2, c.getLecturer());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public ArrayList<Course> getAllCourses() {

        ArrayList<Course> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM course";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Course c = new Course();
                c.setCourseId(rs.getInt("course_id"));
                c.setCourseName(rs.getString("course_name"));
                c.setLecturer(rs.getString("lecturer"));

                list.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public boolean updateCourse(Course c) {
        try {
            Connection con = DBConnection.getConnection();

            String sql = "UPDATE course SET course_name=?, lecturer=? WHERE course_id=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, c.getCourseName());
            ps.setString(2, c.getLecturer());
            ps.setInt(3, c.getCourseId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteCourse(int id) {
        try {
            Connection con = DBConnection.getConnection();

            String sql = "DELETE FROM course WHERE course_id=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}