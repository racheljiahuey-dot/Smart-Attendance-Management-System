package controller;

import java.sql.*;
import java.util.ArrayList;
import model.Attendance;

public class AttendanceController {

    Connection con;

    public AttendanceController() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/smartattendancesystem",
                "root",
                ""
            );

            System.out.println("Database Connected Successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= INSERT ATTENDANCE =================
    public boolean addAttendance(Attendance a) {

        try {

            String sql = "INSERT INTO attendance (student_id, attendance_date, attendance_time, attendance_status) VALUES (?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, a.getStudentId());
            ps.setString(2, a.getDate());
            ps.setString(3, a.getTime());
            ps.setString(4, a.getStatus());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // ================= GET ALL ATTENDANCE =================
    public ArrayList<Attendance> getAllAttendance() {

        ArrayList<Attendance> list = new ArrayList<>();

        try {

            String sql =
                "SELECT " +
                "a.attendance_id, " +
                "a.student_id, " +
                "s.name, " +
                "c.course_name, " +
                "c.lecturer, " +
                "a.attendance_date, " +
                "a.attendance_time, " +
                "a.attendance_status " +
                "FROM attendance a " +
                "JOIN student s ON a.student_id = s.student_id " +
                "JOIN course c ON s.course_id = c.course_id";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Attendance a = new Attendance();

                a.setAttendanceId(rs.getInt(1));
                a.setStudentId(rs.getInt(2));
                a.setStudentName(rs.getString(3));  // student name
                a.setCourseName(rs.getString(4));   // course name
                a.setLecturer(rs.getString(5));     // lecturer
                a.setDate(rs.getString(6));
                a.setTime(rs.getString(7));
                a.setStatus(rs.getString(8));

                list.add(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ================= DELETE ATTENDANCE =================
    public boolean deleteAttendance(int attendanceId) {

        try {

            String sql = "DELETE FROM attendance WHERE attendance_id=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, attendanceId);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // ================= UPDATE ATTENDANCE =================
    public boolean updateAttendance(Attendance a) {

        try {

            String sql = "UPDATE attendance SET student_id=?, attendance_date=?, attendance_time=?, attendance_status=? WHERE attendance_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, a.getStudentId());
            ps.setString(2, a.getDate());
            ps.setString(3, a.getTime());
            ps.setString(4, a.getStatus());
            ps.setInt(5, a.getAttendanceId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // ================= SEARCH BY STUDENT ID =================
    public ArrayList<Attendance> searchByStudentId(int studentId) {

        ArrayList<Attendance> list = new ArrayList<>();

        try {

            String sql = "SELECT * FROM attendance WHERE student_id=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, studentId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Attendance a = new Attendance();

                a.setAttendanceId(rs.getInt("attendance_id"));
                a.setStudentId(rs.getInt("student_id"));
                a.setDate(rs.getString("attendance_date"));
                a.setTime(rs.getString("attendance_time"));
                a.setStatus(rs.getString("attendance_status"));

                list.add(a);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // ================= ATTENDANCE PERCENTAGE =================
    public double getAttendancePercentage(int studentId) {

        int total = 0;
        int present = 0;

        try {

            String sql = "SELECT attendance_status FROM attendance WHERE student_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, studentId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                total++;

                if (rs.getString("attendance_status").equalsIgnoreCase("Present")) {
                    present++;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        if (total == 0) return 0;

        return (present * 100.0) / total;
    }

    // ⭐ NEW ADDITION: WARNING SYSTEM (INNOVATION FEATURE)
    public String getAttendanceWarning(int studentId) {

        double percent = getAttendancePercentage(studentId);

        if (percent < 75) {
            return "⚠ LOW ATTENDANCE WARNING!";
        }
        else {
            return "✔ GOOD ATTENDANCE";
        }
    }
    
 // ================= COUNT PRESENT =================
    public int countPresent() {

        int count = 0;

        try {

            String sql = "SELECT COUNT(*) FROM attendance WHERE attendance_status='Present'";
            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                count = rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return count;
    }

    // ================= COUNT ABSENT =================
    public int countAbsent() {

        int count = 0;

        try {

            String sql = "SELECT COUNT(*) FROM attendance WHERE attendance_status='Absent'";
            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                count = rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return count;
    }
 // ================= COURSE ATTENDANCE ANALYTICS (NEW ADDITION ONLY) =================
    public ArrayList<Object[]> getAttendanceByCourse() {

        ArrayList<Object[]> list = new ArrayList<>();

        try {

            String sql =
                "SELECT c.course_name, " +
                "COUNT(*) as total, " +
                "SUM(CASE WHEN a.attendance_status='Present' THEN 1 ELSE 0 END) as present " +
                "FROM attendance a " +
                "JOIN student s ON a.student_id = s.student_id " +
                "JOIN course c ON s.course_id = c.course_id " +
                "GROUP BY c.course_name";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                String courseName = rs.getString("course_name");
                int present = rs.getInt("present");
                int total = rs.getInt("total");

                list.add(new Object[]{courseName, present, total});
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}