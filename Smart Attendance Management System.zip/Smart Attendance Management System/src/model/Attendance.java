package model;

public class Attendance {

    private int attendanceId;
    private int studentId;
    private String date;
    private String time;
    private String status;
    private String studentName;
    private String courseName;
    private String lecturer;

    // Getter and Setter
    public int getAttendanceId() {
        return attendanceId;
    }

    public void setAttendanceId(int attendanceId) {
        this.attendanceId = attendanceId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public String getStudentName() { 
    	return studentName; 
    }
    public void setStudentName(String studentName) { 
    	this.studentName = studentName; 
    }

    public String getCourseName() { 
    	return courseName; 
    }
    public void setCourseName(String courseName) {
    	this.courseName = courseName; 
    }

    public String getLecturer() {
    	return lecturer; 
    }
    public void setLecturer(String lecturer) {
    	this.lecturer = lecturer;
    }
}